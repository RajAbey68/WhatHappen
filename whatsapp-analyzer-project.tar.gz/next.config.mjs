/** @type {import('next').NextConfig} */
const nextConfig = {
  // Ensure CSS is processed correctly
  webpack: (config, { dev, isServer }) => {
    if (!dev && !isServer) {
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
      }
    }
    return config
  },
}

export default nextConfig 